/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.assignmentone;

import java.io.File;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class MessageTextTest {
    
    // Test data from the assignment
    private final String number1 = "+27718693002";
    private final String text1 = "Hi Mike, can you join us for dinner tonight?";
    private final String number2 = "08575975889";
    private final String text2 = "Hi Keegan, did you receive the payment?";

    @BeforeEach
    public void setUp() {
        Message.resetMessages();                          // start each test with 0 messages sent
        Message.JsonFileName = "test-messages.json";      // use a test file, not the real one
    }

    @AfterEach
    public void cleanUp() {
        new File("test-messages.json").delete();          // delete the test file afterwards
    }

    // ========== MESSAGE LENGTH ==========

    @Test
    public void testMessageLength_Success() {
        Message m = new Message("0000000000", 0, number1, text1);
        assertEquals("Message ready to send.", m.checkMessageLength());
    }

    @Test
    public void testMessageLength_Failure() {
        String longText = "a".repeat(255);   // 5 characters too many
        Message m = new Message("0000000000", 0, number1, longText);
        assertEquals("Message exceeds 250 characters by 5; please reduce the size.", m.checkMessageLength());
    }

    // ========== RECIPIENT NUMBER ==========

    @Test
    public void testRecipientCell_Success() {
        Message m = new Message("0000000000", 0, number1, text1);
        assertEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }

    @Test
    public void testRecipientCell_Failure() {
        Message m = new Message("0000000000", 1, number2, text2);
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            m.checkRecipientCell()
        );
    }

    // ========== MESSAGE HASH ==========

    @Test
    public void testMessageHash_TestCase1() {
        Message m = new Message("0000000000", 0, number1, text1);
        assertEquals("00:0:HITONIGHT", m.createMessageHash());
    }

    // Tests the remaining message hashes in a loop
    @Test
    public void testMessageHash_Loop() {
        String[] texts = {text1, text2, "Hello", "Good morning, see you at the meeting!"};
        String[] expected = {"00:0:HITONIGHT", "00:1:HIPAYMENT", "00:2:HELLOHELLO", "00:3:GOODMEETING"};

        for (int i = 0; i < texts.length; i++) {
            Message m = new Message("0000000000", i, number1, texts[i]);
            assertEquals(expected[i], m.MessageHash);
        }
    }

    // ========== MESSAGE ID ==========

    @Test
    public void testMessageID_Created() {
        Message m = new Message(0, number1, text1);
        assertNotNull(m.MessageID);
        assertEquals(10, m.MessageID.length());
        assertTrue(m.checkMessageID());
        System.out.println("Message ID generated: " + m.MessageID);
    }

    // ========== MESSAGE SENT (Send / Disregard / Store) ==========

    @Test
    public void testSentMessage_Send() {
        Message m = new Message(0, number1, text1);
        assertEquals("Message successfully sent.", m.SentMessage(1));
    }

    @Test
    public void testSentMessage_Disregard() {
        Message m = new Message(1, number2, text2);
        assertEquals("Press 0 to delete the message.", m.SentMessage(2));
    }

    @Test
    public void testSentMessage_Store() {
        Message m = new Message(0, number1, text1);
        assertEquals("Message successfully stored.", m.SentMessage(3));
        assertTrue(new File("test-messages.json").exists());   // the JSON file was created
    }

    // ========== TOTAL MESSAGES ==========

    @Test
    public void testReturnTotalMessages() {
        Message m1 = new Message(0, number1, text1);
        Message m2 = new Message(1, number2, text2);
        m1.SentMessage(1);   // sent
        m2.SentMessage(2);   // disregarded (not sent)
        assertEquals(1, Message.returnTotalMessages());
    }
}
