/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignmentone;

import java.util.Scanner;

/**
 *
 * @author Student
 */
class UserLogin {
    

    // Asks the user for their details, keeps asking until each one is correct,
    // and returns a Login object with the correct details.
    public Login registerUser(Scanner input) {

        System.out.println("======REGISTRATION======");
        System.out.println("Hi there, please enter your name");
        String Name = input.nextLine();

        System.out.println("Hi there, please enter your Surname");
        String Surname = input.nextLine();

        // Username - keep asking until it is correct
        System.out.println("Hi there, please enter your Username");
        String Username = input.nextLine();
        Login check = new Login(Name, Surname, Username, "", "");
        while (!check.checkUserName()) {
            System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            Username = input.nextLine();
            check.Username = Username;
        }
        System.out.println("Username successfully captured.");

        // Password - keep asking until it is correct
        System.out.println("Hi there, please enter your Password");
        String Password = input.nextLine();
        check.Password = Password;
        while (!check.checkPasswordComplexity()) {
            System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            Password = input.nextLine();
            check.Password = Password;
        }
        System.out.println("Password successfully captured.");

        // Cell phone number - keep asking until it is correct
        System.out.println("Hi there, please enter your Cellphone number (for example +27838968976)");
        String Cellphone = input.nextLine();
        check.CellphoneNumber = Cellphone;
        while (!check.checkCellPhoneNumber()) {
            System.out.println(check.returnCellPhoneMessage());
            Cellphone = input.nextLine();
            check.CellphoneNumber = Cellphone;
        }
        System.out.println(check.returnCellPhoneMessage());

        // Create the user with all the correct details
        Login user = new Login(Name, Surname, Username, Password, Cellphone);
        System.out.println(user.registerUser());
        return user;
    }

    // Asks the user to log in. Keeps asking until the username and password
    // match the ones used to register.
    public void loginUser(Scanner input, Login user) {

        System.out.println("\n======LOGIN======");
        boolean loggedIn = false;

        while (!loggedIn) {
            System.out.println("Please enter your Username");
            String loginUsername = input.nextLine();
            System.out.println("Please enter your Password");
            String loginPassword = input.nextLine();

            loggedIn = user.loginUser(loginUsername, loginPassword);
            System.out.println(user.returnLoginStatus(loggedIn));
        }
    }
}