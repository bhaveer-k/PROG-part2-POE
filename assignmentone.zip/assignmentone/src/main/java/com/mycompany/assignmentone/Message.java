/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignmentone;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;

/**
 *
 * @author Student
 */
public class Message {

     // These belong to ALL messages (static), not just one message
    private static String sentMessagesText = "";   // the details of all the messages that were sent
    private static int totalMessagesSent = 0;      // how many were sent

    // The JSON file the messages are stored in (it is created in the project folder)
    public static String JsonFileName = "messages.json";
    String Recipient;
    String MessageText;
    String MessageID;
    Object MessageHash;

    // Constructor used by the program - the ID is generated automatically
    public Message(int messageNumber, String recipient, String messageText) {
        this(generateMessageID(), messageNumber, recipient, messageText);
    }

    // Constructor where the ID is given (this is used for the unit tests)
    public Message(String messageID, int messageNumber, String recipient, String messageText) {
        String MessageID = messageID;
        int MessageNumber = messageNumber;
        String Recipient = recipient;
        String MessageText = messageText;
        String MessageHash = createMessageHash();
    }

    // Creates a random ten-digit number to use as the message ID
    // (the first digit is never 0, so it is always 10 digits long)
    public static String generateMessageID() {
        Random random = new Random();
        long id = 1000000000L + (long) (random.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }

    // The message ID must not be more than ten characters
    public boolean checkMessageID() {
        return MessageID.length() <= 10;
    }

    // Checks the recipient cell number: international code + number (max ten digits)
    // This uses the same check as the Login class (Part 1).
    // Regular expression syntax adapted from: Oracle (n.d.) Class Pattern.
    // Available at: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/regex/Pattern.html
    // [Accessed 17 October 2026].
    public String checkRecipientCell() {
        if (Recipient.matches("^\\+[0-9]{1,3}[0-9]{1,10}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Checks the message is not more than 250 characters
    public String checkMessageLength() {
        if (MessageText.length() <= 250) {
            return "Message ready to send.";
        } else {
            int tooMany = MessageText.length() - 250;
            return "Message exceeds 250 characters by " + tooMany + "; please reduce the size.";
        }
    }

    // Creates the message hash, for example 00:0:HITHANKS
    // = first two numbers of the ID + ":" + message number + ":" + FIRSTWORD + LASTWORD
    public String createMessageHash() {
        String text = MessageText.trim();

        // Find the first word (up to the first space) and the last word (after the last space)
        int firstSpace = text.indexOf(" ");
        int lastSpace = text.lastIndexOf(" ");

        String firstWord;
        String lastWord;
        if (firstSpace == -1) {
            // the message is only one word
            firstWord = text;
            lastWord = text;
        } else {
            firstWord = text.substring(0, firstSpace);
            lastWord = text.substring(lastSpace + 1);
        }

        // Remove punctuation like , ? !
        firstWord = firstWord.replaceAll("[^a-zA-Z0-9]", "");
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");

        String firstTwoNumbers = MessageID.substring(0, 2);
        String MessageNumber = null;

        return (firstTwoNumbers + ":" + MessageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // The user chooses what to do with the message:
    // 1 = Send, 2 = Disregard, 3 = Store to send later
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                sentMessagesText = sentMessagesText + getMessageDetails() + "\n\n";   // keep the details of the sent message
                totalMessagesSent++;                                                  // add 1 to the total
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    // Shows the details of one message in the required order:
    // Message ID, Message Hash, Recipient, Message
    public String getMessageDetails() {
        String MessageID = null;
        String MessageHash = null;
        String Recipient = null;
        String MessageText = null;
        return "Message ID: " + MessageID + "\n"
                + "Message Hash: " + MessageHash + "\n"
                + "Recipient: " + Recipient + "\n"
                + "Message: " + MessageText;
    }

    // Returns all the messages that were sent while the program is running
    public static String printMessages() {
        return sentMessagesText;
    }

    // Returns the total number of messages sent
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // Clears the sent messages (used by the unit tests so each test starts fresh)
    public static void resetMessages() {
        sentMessagesText = "";
        totalMessagesSent = 0;
    }

    // Stores the message in a JSON file.
    // The file holds a list (array) of messages, for example:
    // [
    //   { "messageID": "...", "messageNumber": 0, "recipient": "...", "message": "...", "messageHash": "..." }
    // ]
    // JSON format taken from: JSON (n.d.) Introducing JSON.
    // Available at: https://www.json.org/json-en.html [Accessed 17 October 2026].
    public void storeMessage() {
        String MessageHash = null;
        String MessageID = null;
        String MessageNumber = null;
        String Recipient = null;
        String MessageText = null;
        // This is ONE message written in JSON format
        String newMessage = "  {\n"
                + "    \"messageID\": \"" + escapeJson(MessageID) + "\",\n"
                + "    \"messageNumber\": " + MessageNumber + ",\n"
                + "    \"recipient\": \"" + escapeJson(Recipient) + "\",\n"
                + "    \"message\": \"" + escapeJson(MessageText) + "\",\n"
                + "    \"messageHash\": \"" + escapeJson(MessageHash) + "\"\n"
                + "  }";

        try {
            Path file = Paths.get(JsonFileName);
            String json;

            if (Files.exists(file) && Files.readString(file).trim().endsWith("]")) {
                // The file already has messages: remove the last "]" and add the new message
                String old = Files.readString(file).trim();
                String withoutEnd = old.substring(0, old.length() - 1).trim();

                if (withoutEnd.endsWith("[")) {
                    json = withoutEnd + "\n" + newMessage + "\n]";            // list was empty
                } else {
                    json = withoutEnd + ",\n" + newMessage + "\n]";           // add after the others
                }
            } else {
                // The file does not exist yet: start a new list
                json = "[\n" + newMessage + "\n]";
            }

            Files.writeString(file, json, StandardCharsets.UTF_8);

        } catch (IOException e) {
            System.out.println("Could not store the message: " + e.getMessage());
        }
    }

    // Makes text safe to place inside JSON (for quotes, slashes and new lines)
    private static String escapeJson(String text) {
        return text.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "");
    }
}
