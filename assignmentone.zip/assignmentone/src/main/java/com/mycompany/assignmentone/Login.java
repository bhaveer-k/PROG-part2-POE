/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignmentone;

/**
 *
 * @author Student
 */
public class Login {
    
      // Details of the user, saved when the Login object is created
    public String FirstName;
    public String LastName;
    public String Username;
    public String Password;
    public String CellphoneNumber;

    // Constructor - saves the details the user typed in
    public Login(String name, String surname, String username, String password, String phoneNumber) {

        FirstName = name;
        LastName = surname;
        Username = username;
        Password = password;
        CellphoneNumber = phoneNumber;
    }

    // Username must contain an underscore and be NO MORE than 5 characters long
    public boolean checkUserName() {
        return Username.contains("_") && Username.length() <= 5;
    }

    // Password must be at least 8 characters and contain a capital letter,
    // a number and a special character
    public boolean checkPasswordComplexity() {
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        // Go through the password one character at a time
        for (int i = 0; i < Password.length(); i++) {
            char c = Password.charAt(i);

            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetter(c)) {
                // not a letter and not a number = special character
                hasSpecial = true;
            }
        }

        return Password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    }

    // Cell number must start with the international code (+) followed by the number.
    // The regular expression means: a "+", then 1 to 3 digits for the country code,
    // then 1 to 10 digits for the number
    public boolean checkCellPhoneNumber() {
        return CellphoneNumber.matches("^\\+[0-9]{1,3}[0-9]{1,10}$");
    }

    // Returns the message for the cell phone number check
    public String returnCellPhoneMessage() {
        if (checkCellPhoneNumber()) {
            return "Cell number successfully captured.";
        } else {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }
    }

    // Returns the registration message
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        } else if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        } else {
            return "Username successfully captured.\nPassword successfully captured.";
        }
    }

    // Checks that the login details match the details used to register
    public boolean loginUser(String username, String password) {
        return this.Username.equals(username) && this.Password.equals(password);
    }

    // Returns the message for a successful or a failed login
    public String returnLoginStatus(boolean loginSuccessful) {
        if (loginSuccessful) {
            return "Welcome " + FirstName + ", " + LastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}

    

