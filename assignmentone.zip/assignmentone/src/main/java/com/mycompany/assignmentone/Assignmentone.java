/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignmentone;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Assignmentone {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        //======Part 1=====
        System.out.println("=====REGISTRATION=====");
        System.out.println("hi therre, please enter name");
        String Name = input.nextLine();

        System.out.println("Hi there, please enter your Surname");
        String Surname = input.nextLine();

        // Username - keep asking until it is correct
        System.out.println("Hi there, please enter your Username");
        String Username = input.nextLine();
        Login check = new Login(Name, Surname, Username, "", "");
        while (!check.checkUserName()) {
            System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            Username = input.nextLine();
            check.Username = Username;
        }
        System.out.println("Username successfully captured.");

        // Password - keep asking until it is correct
        System.out.println("Hi there, please enter your Password");
        String Password = input.nextLine();
        check.Password = Password;
        while (!check.checkPasswordComplexity()) {
            System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            Password = input.nextLine();
            check.Password = Password;
        }
        System.out.println("Password successfully captured.");

        // Cell phone number - keep asking until it is correct
        System.out.println("Hi there, please enter your Cellphone number (for example +27838968976)");
        String Cellphone = input.nextLine();
        check.CellphoneNumber = Cellphone;
        while (!check.checkCellPhoneNumber()) {
            System.out.println(check.returnCellPhoneMessage());
            Cellphone = input.nextLine();
            check.CellphoneNumber = Cellphone;
        }
        System.out.println(check.returnCellPhoneMessage());

        // Create the user with all the correct details
        Login user = new Login(Name, Surname, Username, Password, Cellphone);
        System.out.println(user.registerUser());

        // ================= PART 1: LOGIN =================
        // The user must log in before they can use QuickChat
        System.out.println("\n======LOGIN======");
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.println("Please enter your Username");
            String loginUsername = input.nextLine();
            System.out.println("Please enter your Password");
            String loginPassword = input.nextLine();

            loggedIn = user.loginUser(loginUsername, loginPassword);
            System.out.println(user.returnLoginStatus(loggedIn));
        }

        // ================= PART 2: QUICKCHAT =================
        System.out.println("\nWelcome to QuickChat.");

        // The user decides how many messages they want to enter
        int numMessages = readNumber(input, "How many messages do you want to enter?");
        while (numMessages < 1) {
            numMessages = readNumber(input, "Please enter a number of 1 or more.");
        }

        int messagesEntered = 0;   // how many messages the user has already entered
        int option = 0;            // the menu option the user chooses

        // The application keeps running until the user chooses 3 (Quit)
        while (option != 3) {

            System.out.println("\nPlease choose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");

            option = readNumber(input, "Enter 1, 2 or 3:");

            if (option == 1) {
                // Only allow the number of messages the user chose at the start
                if (messagesEntered >= numMessages) {
                    System.out.println("You have already entered all " + numMessages + " messages.");
                } else {
                    messagesEntered = sendMessages(input, numMessages, messagesEntered);
                }
            } else if (option == 2) {
                System.out.println("Coming Soon.");
            } else if (option == 3) {
                System.out.println("Goodbye!");
            } else {
                System.out.println("Invalid option, please enter 1, 2 or 3.");
            }
        }
    }

    // Lets the user enter messages until they have entered the number they chose.
    // Returns how many messages have been entered so far.
    public static int sendMessages(Scanner input, int numMessages, int messagesEntered) {

        while (messagesEntered < numMessages) {

            System.out.println("\n--- Message " + (messagesEntered + 1) + " of " + numMessages + " ---");

            // Recipient - keep asking until the number is correct
            System.out.println("Please enter the recipient's cell number (for example +27718693002)");
            String recipient = input.nextLine();
            Message check = new Message(messagesEntered, recipient, "check");
            while (!check.checkRecipientCell().equals("Cell phone number successfully captured.")) {
                System.out.println(check.checkRecipientCell());
                recipient = input.nextLine();
                check.Recipient = recipient;
            }
            System.out.println(check.checkRecipientCell());

            // Message text - keep asking until it is 250 characters or less
            System.out.println("Please enter your message");
            String text = input.nextLine();
            while (text.trim().isEmpty() || text.length() > 250) {
                if (text.trim().isEmpty()) {
                    System.out.println("The message cannot be empty, please try again.");
                } else {
                    System.out.println("Please enter a message of less than 250 characters.");
                    check.MessageText = text;
                    System.out.println(check.checkMessageLength());
                }
                text = input.nextLine();
            }

            // Create the message (the ID and the hash are created automatically)
            Message message = new Message(messagesEntered, recipient, text);
            System.out.println("Message ID generated: " + message.MessageID);
            System.out.println(message.checkMessageLength());

            // The user chooses what to do with the message
            System.out.println("\nWhat would you like to do with this message?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            int choice = readNumber(input, "Enter 1, 2 or 3:");
            while (choice < 1 || choice > 3) {
                choice = readNumber(input, "Invalid option, please enter 1, 2 or 3:");
            }

            System.out.println(message.SentMessage(choice));

            if (choice == 1) {
                // Show the full details of the message that was sent
                System.out.println("\n" + message.getMessageDetails());
            } else if (choice == 2) {
                // The user must press 0 to delete the message
                int delete = readNumber(input, "Enter 0 to delete the message:");
                while (delete != 0) {
                    delete = readNumber(input, "Press 0 to delete the message:");
                }
                System.out.println("Message deleted.");
            }

            messagesEntered++;
        }

        // All the messages have been entered - show the total that were sent
        System.out.println("\nTotal number of messages sent: " + Message.returnTotalMessages());
        return messagesEntered;
    }

    // Asks the question and returns the number the user typed.
    // If the user types something that is not a number, it asks again
    // (this stops the program from crashing).
    public static int readNumber(Scanner input, String question) {
        System.out.println(question);
        while (true) {
            String text = input.nextLine().trim();
            try {
                return Integer.parseInt(text);
            } catch (NumberFormatException e) {
                System.out.println("That is not a number, please enter a number.");
            }
        }
    }
}

